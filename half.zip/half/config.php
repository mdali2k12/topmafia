<?php

		$_CONFIG = array(
			'hostname' => 'localhost',
			'username' => 'topmafia_admin',
			'password' => ';,iOL%X1A!#D',
			'database' => 'topmafia_database',
			'persistent' => 0,
			'driver' => 'mysqli',
			'code' => 'JE939E3QC783ttt483D9CX'
		);
	

?>